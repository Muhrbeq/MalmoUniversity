﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apu_Animal_Park.Animals
{
    /// <summary>
    /// All Genders of animals
    /// </summary>
    public enum GenderType
    {
        Female,
        Male,
        Unknown
    }
}

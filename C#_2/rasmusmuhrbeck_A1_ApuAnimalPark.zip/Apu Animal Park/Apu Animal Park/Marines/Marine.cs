﻿using Apu_Animal_Park.Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apu_Animal_Park.Marines
{
    internal class Marine : Animal
    {
        private double _swimSpeed;
        private string _eatsFish;

        public Marine(double swimSpeed, string eatsFish)
        {
            _swimSpeed = swimSpeed;
            _eatsFish = eatsFish;
        }
        
        /// <summary>
        /// Creates Marine
        /// </summary>
        /// <param name="species">Specie of marine</param>
        /// <param name="swimSpeed">Swim speed of animal</param>
        /// <param name="eatsFish">Eats fish [y/n]</param>
        /// <returns>Returns animal based on specie</returns>
        public Marine CreateMarine(MarineSpecies species, double swimSpeed, string eatsFish)
        {
            Marine marine = null;

            switch (species)
            {
                case MarineSpecies.Dolphin:
                    marine = new Dolphin(swimSpeed, eatsFish);
                    break;

                case MarineSpecies.Shark:
                    marine = new Shark(swimSpeed, eatsFish);
                    break;
            }

            return marine;
        }

        public double SwimSpeed
        {
            get { return _swimSpeed; }
            set { _swimSpeed = value; }
        }

        public string EatsFish
        {
            get { return _eatsFish; }
            set { _eatsFish = value; }
        }

        /// <summary>
        /// Overloaded tostring method.
        /// </summary>
        /// <returns>Returns a string containing info about animal</returns>
        public override string ToString()
        {
            string strOut = base.ToString();
            strOut += String.Format("Swim speed: {0}\rEats fish: {1}\r", _swimSpeed, _eatsFish);

            return strOut;
        }

    }

    public enum MarineSpecies
    {
        Dolphin,
        Shark
    }
}

﻿using Apu_Animal_Park.Animals;
using Apu_Animal_Park.Birds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apu_Animal_Park.Insects
{
    internal class Insect : Animal
    {
        private int _numOfEyes;
        private double _size;

        public Insect(int numOfEyes, double size)
        {
            _numOfEyes = numOfEyes;
            _size = size;
        }

        /// <summary>
        /// Creates insect based on specie
        /// </summary>
        /// <param name="species">Specie of insect</param>
        /// <param name="numOfEyes">Number of eyes on insect</param>
        /// <param name="size">size in cm of insect</param>
        /// <returns></returns>
        public Insect CreateInsect(InsectSpecies species, int numOfEyes, double size)
        {
            Insect insect = null;

            switch (species)
            {
                case InsectSpecies.Bee:
                    insect = new Bee(numOfEyes, size);
                    break;

                case InsectSpecies.Spider:
                    insect = new Spider(numOfEyes, size);
                    break;
            }

            return insect;
        }

        public int NumOfEyes
        {
            get { return _numOfEyes; }
            set { _numOfEyes = value; }
        }

        public double Size
        {
            get { return _size; }
            set { _size = value; }
        }

        /// <summary>
        /// Overloaded tostring method.
        /// </summary>
        /// <returns>Returns a string containing info about animal</returns>
        public override string ToString()
        {
            string strOut = base.ToString();
            strOut += String.Format("Number of eyes: {0}\rSize [cm]: {1}\r", _numOfEyes, _size);

            return strOut;
        }
    }

    public enum InsectSpecies
    {
        Bee,
        Spider
    }
}

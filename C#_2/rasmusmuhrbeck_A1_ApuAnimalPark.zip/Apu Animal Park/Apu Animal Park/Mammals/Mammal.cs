﻿using Apu_Animal_Park.Animals;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Apu_Animal_Park
{
    internal class Mammal : Animal
    {
        private int _amountOfLegs;
        private int _numberOfTeeth;


        public Mammal(int numberOfTeeth, int amountOfLegs)
        {
            _amountOfLegs = amountOfLegs;
            _numberOfTeeth = numberOfTeeth;
        }

        /// <summary>
        /// Creates mammal based on specie
        /// </summary>
        /// <param name="species">specie of mammal</param>
        /// <param name="numOfTeeth">Number of teeth on mammal</param>
        /// <param name="numOfLegs">Number of legs on mammal</param>
        /// <returns>Returns a mammal based on specie</returns>
        public Mammal CreateMammal(MammalSpecies species, int numOfTeeth, int numOfLegs)
        {
            Mammal mammal = null;

            switch (species)
            {
                case MammalSpecies.Dog:
                    mammal = new Dog(numOfTeeth, numOfLegs);
                    break;

                case MammalSpecies.Monkey:
                    mammal = new Monkey(numOfTeeth, numOfLegs);
                    break;
            }

            return mammal;
        }

        public int AmountOfLegs
        {
            get { return _amountOfLegs;}
            set { _amountOfLegs = value;}
        }

        public int NumberOfTeeth
        {
            get { return _numberOfTeeth;}
            set { _numberOfTeeth = value;}
        }

        /// <summary>
        /// Overloaded tostring method.
        /// </summary>
        /// <returns>Returns a string containing info about animal</returns>
        public override string ToString()
        {
            string strOut = base.ToString();
            strOut += String.Format("Amount of legs: {0}\rAmount of teeth: {1}\r", _amountOfLegs, _numberOfTeeth);

            return strOut;
        }
    }

    public enum MammalSpecies
    {
        Dog,
        Monkey
    }
}
